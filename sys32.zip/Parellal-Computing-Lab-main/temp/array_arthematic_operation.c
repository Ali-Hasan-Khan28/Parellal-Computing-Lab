#include<stdlib.h>
#include<stdio.h>
#include<time.h> 
int multi(int *arr,int soa)
{
    int mul = 1;
    for(int i=0;i<soa;i++)
    {
        mul = mul * arr[i];
    }
    return mul;
}
int main(int argc, char* argv[])
{
    int soa = atoi(argv[1]);
    int *arr = (int*)malloc(soa * sizeof(int));
    int mynum;
    for(int i=0; i<soa;i++)
    {
        scanf("%d" , &mynum);
        arr[i] = mynum;
    }
        for(int i=0; i<soa;i++)
    {
        printf("%d",arr[i]);
    }
    int k = multi(arr,soa);
    printf("The result is :: %d", k);

}