#include<stdlib.h>
#include<stdio.h>
#include<pthread.h>

pthread_mutex_t mutex;

int balance = 1000;

void *customer_thread(void* arg)
{
    int id = *((int*)arg);

    for(int i=0;i<5;i++)
    {
        int amount = rand()%100 + 1;
        int action = rand()%2;

        pthread_mutex_lock(&mutex);

        if(action == 0)
        {
            balance = balance + amount;
            printf("%d, %d deposit \n", balance, amount);
        }
        else
        {
            balance = balance - amount;
            printf("%d, %d credit \n", balance, amount);
        }

        pthread_mutex_unlock(&mutex);
    }

}

int main(int argc, char * argv[])
{
    srand(time(NULL));

    pthread_mutex_init(&mutex,NULL);

    pthread_t thread[4];
    int thread_ids[4];

    for(int i=0;i<4;i++)
    {
        pthread_create(&thread[i],NULL,customer_thread,&thread_ids[i]);
    }

    for(int i=0;i<4;i++)
    {
        pthread_join(thread[i],NULL);
    }

    pthread_mutex_destroy(&mutex);
}