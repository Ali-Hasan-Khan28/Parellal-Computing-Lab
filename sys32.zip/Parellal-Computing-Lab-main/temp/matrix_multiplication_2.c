#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define SIZE 4 // size of matrices
#define NUM_THREADS 4 // number of threads to spawn

int A[SIZE][SIZE]; // matrix A
int B[SIZE][SIZE]; // matrix B
int C[SIZE][SIZE]; // result matrix C

pthread_mutex_t mutex; // mutex for protecting access to C
pthread_barrier_t barrier; // barrier for synchronizing threads

// function for each thread to calculate a specific row of C
void *calculate_row(void *arg) {
    int row = *(int *)arg; // get the row number from argument
    int i, j, k;
    
    // calculate row of C
    for (i = row; i < row + 1; i++) {
        for (j = 0; j < SIZE; j++) {
            for (k = 0; k < SIZE; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    
    // synchronize threads at barrier
    pthread_barrier_wait(&barrier);
    
    // print thread's calculated row
    printf("Thread %d calculated row %d of C\n", row + 1, row + 1);
    
    // exit thread
    pthread_exit(NULL);
}

int main() {
    int i, j;
    pthread_t threads[NUM_THREADS]; // array of threads
    int rows[NUM_THREADS]; // array of row numbers for threads
    
    // initialize mutex and barrier
    pthread_mutex_init(&mutex, NULL);
    pthread_barrier_init(&barrier, NULL, NUM_THREADS);
    
    // generate random matrices A and B
    printf("Matrix A:\n");
    for (i = 0; i < SIZE; i++) {
        for (j = 0; j < SIZE; j++) {
            A[i][j] = rand() % 10;
            printf("%d ", A[i][j]);
        }
        printf("\n");
    }
    
    printf("\nMatrix B:\n");
    for (i = 0; i < SIZE; i++) {
        for (j = 0; j < SIZE; j++) {
            B[i][j] = rand() % 10;
            printf("%d ", B[i][j]);
        }
        printf("\n");
    }
    
    // spawn threads
    for (i = 0; i < NUM_THREADS; i++) {
        rows[i] = i; // assign row number to thread
        pthread_create(&threads[i], NULL, calculate_row, &rows[i]);
    }
    
    // join threads
    for (i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }
    
    // print result matrix C
    printf("\nResult Matrix C:\n");
    for (i = 0; i < SIZE; i++) {
        for (j = 0; j < SIZE; j++) {
            printf("%d ", C[i][j]);
        }
        printf("\n");
    }
    
    // destroy mutex and barrier
    pthread_mutex_destroy(&mutex);
    pthread_barrier_destroy(&barrier);
    
    return 0;
}
