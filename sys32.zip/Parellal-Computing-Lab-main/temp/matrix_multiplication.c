#include <stdlib.h>
#include <stdio.h>

// Function to take matrix input
void taking_matrix_input(int **arr, int row, int col)
{
    printf("Enter the matrix elements:\n");
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            scanf("%d", &arr[i][j]);  // Correctly read values into the array
        }
    }
}

// Function to print the matrix
void printing(int **arr, int row, int col)
{
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            printf("%d ", arr[i][j]);  // Properly print the matrix element
        }
        printf("\n");
    }
}

int main(int argc, char *argv[])
{
    if (argc < 3)
    {
        printf("Usage: %s <rows> <columns>\n", argv[0]);
        return 1;  // Exit if not enough arguments
    }

    int row = atoi(argv[1]);
    int col = atoi(argv[2]);

    // Allocate memory for matrix A
    int **mata = (int **)malloc(row * sizeof(int *));
    for (int i = 0; i < row; i++)
    {
        mata[i] = (int *)malloc(col * sizeof(int));
    }

    // Input matrix A
    taking_matrix_input(mata, row, col);

    // Allocate memory for matrix B
    int **matb = (int **)malloc(row * sizeof(int *));
    for (int i = 0; i < row; i++)
    {
        matb[i] = (int *)malloc(col * sizeof(int));
    }

    // Input matrix B
    taking_matrix_input(matb, row, col);

    // Print both matrices
    printf("Matrix A:\n");
    printing(mata, row, col);

    printf("Matrix B:\n");
    printing(matb, row, col);

    // Allocate memory for matrix C (result of element-wise multiplication)
    int **matc = (int **)malloc(row * sizeof(int *));
    for (int i = 0; i < row; i++)
    {
        matc[i] = (int *)malloc(col * sizeof(int));
    }

    // Perform element-wise multiplication of matrices A and B
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            matc[i][j] = mata[i][j] * matb[i][j];
        }
    }

    // Print the resultant matrix C
    printf("The resultant matrix C (element-wise multiplication):\n");
    printing(matc, row, col);
}
    