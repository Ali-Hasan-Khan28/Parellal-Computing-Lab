#include<stdlib.h>
#include<stdio.h>
#include<pthread.h>
#include<unistd.h>

int num_cars = 4;

int checkpoints = 3;

pthread_barrier_t barrier;

void *checkpointing(void * arg)
{
    int id = *((int*)arg);
    for(int i=0;i<checkpoints;i++)
    {
        usleep(10000);

        printf("Car %d reached checkpoint %d \n", id, i);
        
        pthread_barrier_wait(&barrier);
    }
    return NULL;
}

int main(int argc, char *argv[])
{
    pthread_barrier_init(&barrier, NULL, num_cars);
    pthread_t thread[num_cars];
    int thread_id[num_cars];

    for(int i=0;i<num_cars;i++)
    {
        thread_id[i] = i;
        pthread_create(&thread[i],NULL,checkpointing,&thread_id[i]);
    }

    for(int i=0;i<num_cars;i++)
    {
        pthread_join(thread[i],NULL);
    }
    pthread_barrier_destroy(&barrier);
    return 0;
}