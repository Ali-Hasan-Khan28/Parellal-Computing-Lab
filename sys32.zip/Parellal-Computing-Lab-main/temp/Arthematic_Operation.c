#include<stdio.h>
#include<stdlib.h>

float add(float a,float b)
{
    return a + b;
}
float mult(float a,float b)
{
    return a * b;
}
float divi(float a,float b)
{
    return a / b;
}
float sub(float a,float b)
{
    return a - b;
}
int main(int argc, char* argv[])
{
    float num1 = atof(argv[1]);
    char op = argv[2][0];
    float num2 = atof(argv[3]);

    switch (op)
    {
        case '+':
                printf("The additon is %f", add(num1,num2));
                break;
        case 'x':
                printf("The multiplication is %f", mult(num1,num2));
                break;
        case '/':
                printf("The division is %f", divi(num1,num2));
                break;
        case '-':
                printf("The subtraction is %f", sub(num1,num2));
                break;
    }

}