#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define ARRAY_SIZE 5

int main() {
    int array[ARRAY_SIZE];
    int sum = 0;

    // Seed the random number generator
    //srand(time(NULL));

    // Initialize the array with random values
    for (int i = 0; i < ARRAY_SIZE; i++) {
        array[i] = rand(); // Random values between 0 and 99
    }

    // Print the array (optional)
    printf("Array: ");
    for (int i = 0; i < ARRAY_SIZE; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    #pragma omp parallal for reduction(-:sum)
    {
        for(int i=0;i<ARRAY_SIZE;i++)
        {
            sum -= array[i];
        }
    }

    // Print the result
    printf("Sum of array elements: %d\n", sum);

    return 0;
}