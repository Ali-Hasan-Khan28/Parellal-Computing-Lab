#include <stdio.h>
#include <stdlib.h>

void transpose(int *matrix, int rows, int cols, int *transposed_matrix)
{
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            transposed_matrix[j * rows + i] = matrix[i * cols + j];
        }
    }
}

int multiply_matrices(int *M, int rowsM, int colsM, int *N, int rowsN, int colsN, int *result)
{
    if (colsM != rowsN)
    {
        return 0; // Multiplication not possible
    }
    // Initialize result matrix to 0
    for (int i = 0; i < rowsM * colsN; i++)
    {
        result[i] = 0;
    }
    // Matrix multiplication
    for (int i = 0; i < rowsM; i++)
    {
        for (int j = 0; j < colsN; j++)
        {
            for (int k = 0; k < colsM; k++)
            {
                result[i * colsN + j] += M[i * colsM + k] * N[k * colsN + j];
            }
        }
    }
    return 1; // Multiplication successful
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (file == NULL)
    {
        printf("Error opening file.\n");
        return 1;
    }

    int num_cases;
    fscanf(file, "%d", &num_cases);

    for (int case_num = 1; case_num <= num_cases; case_num++)
    {
        int rowsM, colsM, rowsN, colsN;

        // Reading dimensions and elements of matrices M and N
        fscanf(file, "%d %d", &rowsM, &colsM);
        int *M = (int *)malloc(rowsM * colsM * sizeof(int));
        for (int i = 0; i < rowsM * colsM; i++)
        {
            fscanf(file, "%d", &M[i]);
        }

        fscanf(file, "%d %d", &rowsN, &colsN);
        int *N = (int *)malloc(rowsN * colsN * sizeof(int));
        for (int i = 0; i < rowsN * colsN; i++)
        {
            fscanf(file, "%d", &N[i]);
        }

        int *result = (int *)malloc(rowsM * colsN * sizeof(int));

        // Try multiplying matrices directly
        if (!multiply_matrices(M, rowsM, colsM, N, rowsN, colsN, result))
        {
            // If multiplication failed, try with transposed N
            int *transposedN = (int *)malloc(colsN * rowsN * sizeof(int));
            transpose(N, rowsN, colsN, transposedN);

            if (!multiply_matrices(M, rowsM, colsM, transposedN, colsN, rowsN, result))
            {
                printf("Case #%d: Not possible\n", case_num);
                free(M);
                free(N);
                free(transposedN);
                free(result);
                continue;
            }

            free(transposedN);
        }

        // Sum of resultant matrix
        int sum = 0;
        for (int i = 0; i < rowsM * colsN; i++)
        {
            sum += result[i];
        }

        printf("Case #%d: %d\n", case_num, sum);

        // Free dynamically allocated memory
        free(M);
        free(N);
        free(result);
    }

    fclose(file);
    return 0;
}
