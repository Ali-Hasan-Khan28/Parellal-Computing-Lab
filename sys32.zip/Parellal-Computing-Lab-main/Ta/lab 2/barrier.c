#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_THREADS 4

pthread_barrier_t barrier; // Barrier declaration

void *thread_task(void *arg)
{
    int thread_num = *((int *)arg);

    // Task before the barrier
    printf("Thread %d performing task before barrier.\n", thread_num);

    // Simulate some work with sleep
    sleep(1);

    // Wait at the barrier
    pthread_barrier_wait(&barrier);

    // Task after the barrier
    printf("Thread %d performing task after barrier.\n", thread_num);

    return NULL;
}

int main()
{
    pthread_t threads[NUM_THREADS];
    int thread_ids[NUM_THREADS];

    // Initialize the barrier with the number of threads
    pthread_barrier_init(&barrier, NULL, NUM_THREADS);

    // Create the threads
    for (int i = 0; i < NUM_THREADS; i++)
    {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, thread_task, &thread_ids[i]);
    }

    // Wait for all threads to complete
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }

    // Destroy the barrier
    pthread_barrier_destroy(&barrier);

    return 0;
}
