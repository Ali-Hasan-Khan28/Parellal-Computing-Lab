#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

int read_count = 0;                         // Number of active readers
pthread_mutex_t rw_mutex, read_count_mutex; // Mutexes for controlling access

// Reader function
void *reader(void *arg)
{
    while (1)
    {
        // Lock the reader count
        pthread_mutex_lock(&read_count_mutex);
        read_count++;
        if (read_count == 1)
        {
            pthread_mutex_lock(&rw_mutex); // Block writers if there is at least one reader
        }
        pthread_mutex_unlock(&read_count_mutex);

        // Reading section
        printf("Reader %ld is reading.\n", (long)arg);
        sleep(1); // Simulate reading time

        // Lock the reader count and exit the reading section
        pthread_mutex_lock(&read_count_mutex);
        read_count--;
        if (read_count == 0)
        {
            pthread_mutex_unlock(&rw_mutex); // Unblock writers if no readers are left
        }
        pthread_mutex_unlock(&read_count_mutex);

        sleep(1); // Simulate time between readings
    }
}

// Writer function
void *writer(void *arg)
{
    while (1)
    {
        // Lock to ensure exclusive writing access
        pthread_mutex_lock(&rw_mutex);

        // Writing section
        printf("Writer %ld is writing.\n", (long)arg);
        sleep(1); // Simulate writing time

        // Unlock the writer lock
        pthread_mutex_unlock(&rw_mutex);

        sleep(2); // Simulate time between writings
    }
}

int main()
{
    pthread_t readers[3], writers[2];

    // Initialize mutexes
    pthread_mutex_init(&rw_mutex, NULL);
    pthread_mutex_init(&read_count_mutex, NULL);

    // Create reader threads
    for (long i = 0; i < 3; i++)
    {
        pthread_create(&readers[i], NULL, reader, (void *)i);
    }

    // Create writer threads
    for (long i = 0; i < 2; i++)
    {
        pthread_create(&writers[i], NULL, writer, (void *)i);
    }

    // Join threads (they run indefinitely in this example)
    for (int i = 0; i < 3; i++)
    {
        pthread_join(readers[i], NULL);
    }
    for (int i = 0; i < 2; i++)
    {
        pthread_join(writers[i], NULL);
    }

    // Destroy mutexes
    pthread_mutex_destroy(&rw_mutex);
    pthread_mutex_destroy(&read_count_mutex);

    return 0;
}
