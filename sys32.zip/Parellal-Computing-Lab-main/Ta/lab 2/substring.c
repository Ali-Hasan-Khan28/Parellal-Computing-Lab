#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to find and replace all occurrences of a substring
char *findAndReplace(char *largeStr, char *findStr, char *replaceStr)
{
    int largeLen = strlen(largeStr);
    int findLen = strlen(findStr);
    int replaceLen = strlen(replaceStr);

    // Count the number of occurrences of findStr in largeStr
    int count = 0;
    for (int i = 0; i < largeLen; i++)
    {
        if (strstr(&largeStr[i], findStr) == &largeStr[i])
        {
            count++;
            i += findLen - 1; // Move the index forward to avoid overlapping
        }
    }

    // If no occurrences are found, return the original string
    if (count == 0)
    {
        char *result = (char *)malloc((largeLen + 1) * sizeof(char));
        strcpy(result, largeStr);
        return result;
    }

    // Calculate the new length of the modified string
    int newLen = largeLen + count * (replaceLen - findLen);

    // Allocate memory for the new string
    char *result = (char *)malloc((newLen + 1) * sizeof(char));

    int i = 0, j = 0;
    while (*largeStr)
    {
        if (strstr(largeStr, findStr) == largeStr)
        {
            // Replace the substring
            strcpy(&result[j], replaceStr);
            j += replaceLen;
            largeStr += findLen;
        }
        else
        {
            // Copy the original character
            result[j++] = *largeStr++;
        }
    }

    result[j] = '\0'; // Null-terminate the string
    return result;
}

int main()
{
    char largeStr[1000], findStr[100], replaceStr[100];

    // Input large string
    printf("Enter the large string: ");
    fgets(largeStr, sizeof(largeStr), stdin);
    largeStr[strcspn(largeStr, "\n")] = '\0'; // Remove trailing newline character

    // Input substring to find
    printf("Enter the substring to find: ");
    fgets(findStr, sizeof(findStr), stdin);
    findStr[strcspn(findStr, "\n")] = '\0'; // Remove trailing newline character

    // Input substring to replace with
    printf("Enter the substring to replace with: ");
    fgets(replaceStr, sizeof(replaceStr), stdin);
    replaceStr[strcspn(replaceStr, "\n")] = '\0'; // Remove trailing newline character

    // Find and replace all occurrences
    char *modifiedStr = findAndReplace(largeStr, findStr, replaceStr);

    // Print the modified string
    printf("Modified string: %s\n", modifiedStr);

    // Free allocated memory
    free(modifiedStr);

    return 0;
}
