#include <stdio.h>
#include <pthread.h>

int counter = 0;      // Shared counter
pthread_mutex_t lock; // Mutex lock

void *increment_counter(void *arg)
{
    for (int i = 0; i < 100000; i++)
    {
        pthread_mutex_lock(&lock);   // Lock mutex
        counter++;                   // Increment shared counter
        pthread_mutex_unlock(&lock); // Unlock mutex
    }
    return NULL;
}

int main()
{
    pthread_t thread1, thread2;
    pthread_mutex_init(&lock, NULL); // Initialize the mutex

    // Create two threads that increment the counter
    pthread_create(&thread1, NULL, increment_counter, NULL);
    pthread_create(&thread2, NULL, increment_counter, NULL);

    // Wait for both threads to finish
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    printf("Final counter value with mutex: %d\n", counter);

    pthread_mutex_destroy(&lock); // Destroy the mutex
    return 0;
}
