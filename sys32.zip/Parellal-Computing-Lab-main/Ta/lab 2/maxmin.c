#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <limits.h>

#define SIZE 4        // Size of the matrix (4x4)
#define NUM_THREADS 4 // Number of threads

int matrix[SIZE][SIZE];   // Matrix
int global_max = INT_MIN; // Global maximum value initialized to the minimum possible value
pthread_mutex_t lock;     // Mutex for protecting access to global_max

// Thread function to find the maximum element in a specific set of rows
void *find_max(void *arg)
{
    int thread_id = *((int *)arg);
    int local_max = INT_MIN;

    // Each thread processes its assigned row
    for (int i = thread_id; i < SIZE; i += NUM_THREADS)
    {
        for (int j = 0; j < SIZE; j++)
        {
            if (matrix[i][j] > local_max)
            {
                local_max = matrix[i][j];
            }
        }
    }

    // Lock to update the global maximum
    pthread_mutex_lock(&lock);
    if (local_max > global_max)
    {
        global_max = local_max;
    }
    pthread_mutex_unlock(&lock);

    return NULL;
}

// Function to generate a random matrix
void generate_random_matrix(int matrix[SIZE][SIZE])
{
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            matrix[i][j] = rand() % 100; // Random values between 0 and 99
        }
    }
}

// Function to print the matrix
void print_matrix()
{
    printf("Matrix:\n");
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    pthread_t threads[NUM_THREADS];
    int thread_ids[NUM_THREADS];

    // Initialize the matrix
    generate_random_matrix(matrix);
    print_matrix();

    // Initialize the mutex
    pthread_mutex_init(&lock, NULL);

    // Create threads
    for (int i = 0; i < NUM_THREADS; i++)
    {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, find_max, &thread_ids[i]);
    }

    // Wait for threads to finish
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }

    // Print the maximum value found
    printf("Maximum value in the matrix: %d\n", global_max);

    // Destroy the mutex
    pthread_mutex_destroy(&lock);

    return 0;
}
