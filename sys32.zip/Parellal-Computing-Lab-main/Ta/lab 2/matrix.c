#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

#define SIZE 4 // Size of the matrices (4x4)

// Matrices
int A[SIZE][SIZE], B[SIZE][SIZE], C[SIZE][SIZE];

// Mutex for protecting access to the result matrix C
pthread_mutex_t lock;

// Barrier to synchronize threads
pthread_barrier_t barrier;

// Function to multiply a row of matrix A with matrix B and store the result in matrix C
void *multiply_row(void *arg)
{
    int row = *((int *)arg); // Get the row to calculate

    for (int col = 0; col < SIZE; col++)
    {
        int sum = 0;
        for (int k = 0; k < SIZE; k++)
        {
            sum += A[row][k] * B[k][col];
        }

        // Protect access to the shared result matrix C
        pthread_mutex_lock(&lock);
        C[row][col] = sum;
        pthread_mutex_unlock(&lock);
    }

    // Wait at the barrier until all threads finish their row calculations
    pthread_barrier_wait(&barrier);

    return NULL;
}

// Function to print a matrix
void print_matrix(int matrix[SIZE][SIZE], const char *name)
{
    printf("%s:\n", name);
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

// Function to initialize a matrix with random values
void generate_random_matrix(int matrix[SIZE][SIZE])
{
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            matrix[i][j] = rand() % 10; // Random values between 0 and 9
        }
    }
}

int main()
{
    pthread_t threads[SIZE];
    int row_indices[SIZE];

    // Initialize matrices A and B with random values
    generate_random_matrix(A);
    generate_random_matrix(B);

    // Initialize mutex and barrier
    pthread_mutex_init(&lock, NULL);
    pthread_barrier_init(&barrier, NULL, SIZE);

    // Print matrices A and B
    print_matrix(A, "Matrix A");
    print_matrix(B, "Matrix B");

    // Create threads for each row of matrix C
    for (int i = 0; i < SIZE; i++)
    {
        row_indices[i] = i;
        pthread_create(&threads[i], NULL, multiply_row, &row_indices[i]);
    }

    // Wait for all threads to finish
    for (int i = 0; i < SIZE; i++)
    {
        pthread_join(threads[i], NULL);
    }

    // Print the resulting matrix C
    print_matrix(C, "Result Matrix C");

    // Destroy mutex and barrier
    pthread_mutex_destroy(&lock);
    pthread_barrier_destroy(&barrier);

    return 0;
}
