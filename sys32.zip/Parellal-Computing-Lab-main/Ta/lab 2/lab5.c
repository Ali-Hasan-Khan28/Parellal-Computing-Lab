#include <stdio.h>
#include <omp.h>

#define N 1000 // Size of the array
#define CHUNK_SIZE 100 // Size of each chunk

int main() {
    int array[N];
    long long total_sum = 0;

    // Initialize the array with values from 1 to 1000
    for (int i = 0; i < N; i++) {
        array[i] = i + 1;
    }

    // Begin parallel region
    #pragma omp parallel
    {
        // Using a single construct to ensure only one thread initiates task creation
        #pragma omp single
        {
            for (int i = 0; i < N; i += CHUNK_SIZE) {
                // Create a task for each chunk
                #pragma omp task firstprivate(i)
                {
                    long long chunk_sum = 0;
                    for (int j = i; j < i + CHUNK_SIZE && j < N; j++) {
                        chunk_sum += array[j];
                    }
                    


                    // Print the thread ID responsible for this chunk
                    printf("Thread %d processing chunk starting at index %d\n", omp_get_thread_num(), i);

                    // Atomically update the shared total_sum variable
                    #pragma omp atomic
                    total_sum += chunk_sum;
                }
            }
        }

        // Ensure all tasks are completed before proceeding
        #pragma omp taskwait
    }

    // Output the final total sum
    printf("Total sum of array elements: %lld\n", total_sum);

    return 0;
}
