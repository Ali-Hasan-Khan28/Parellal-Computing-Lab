#include <stdio.h>
#include <omp.h>

#define N 1000
#define CHUNK_SIZE 100

int main()
{
    int A[N];
    int total_sum = 0;

    for (int i = 0; i < N; i++)
    {
        A[i] = i + 1;
    }

#pragma omp parallel
    {
#pragma omp for
        for (int i = 0; i < N; i += CHUNK_SIZE)
        {
            int chunk_sum = 0;

            for (int j = i; j < i + CHUNK_SIZE && j < N; j++)
            {
                chunk_sum += A[j];
            }

#pragma omp critical
            {
                printf("Thread %d processed chunk starting at index %d, sum = %d\n",
                       omp_get_thread_num(), i, chunk_sum);
            }

#pragma omp atomic
            total_sum += chunk_sum;
        }
    }

    printf("Total sum of the array: %d\n", total_sum);

    return 0;
}
