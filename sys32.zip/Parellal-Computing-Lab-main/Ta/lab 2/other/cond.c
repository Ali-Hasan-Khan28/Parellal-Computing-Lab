#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<pthread.h>

int buffer_size;
int num_producers;
int num_consumers;


pthread_mutex_t mutex;
pthread_cond_t buffer_not_full=PTHREAD_COND_INITIALIZER;
pthread_cond_t buffer_not_empty=PTHREAD_COND_INITIALIZER;

int*array;
int count=0;

void* producer(void* arg)
{
    int thread_num=*(int*)arg;

    while(1)
    {
        sleep(1);
        int part=rand()%100;
        pthread_mutex_lock(&mutex);
        while(count>=buffer_size)
        {
            pthread_cond_wait(&buffer_not_full,&mutex);
        }
        array[count]=part;
        count++;
        pthread_cond_signal(&buffer_not_empty);
        pthread_mutex_unlock(&mutex);
    }
}

void* producer(void* arg)
{
    int thread_num=*(int*)arg;

    while(1)
    {
        sleep(1);
        pthread_mutex_lock(&mutex);
        while(count<3)
        {
            pthread_cond_wait(&buffer_not_empty,&mutex);
        }
        
        count-=3;
        pthread_cond_signal(&buffer_not_full);
        pthread_mutex_unlock(&mutex);
    }
}

int main()
{



}