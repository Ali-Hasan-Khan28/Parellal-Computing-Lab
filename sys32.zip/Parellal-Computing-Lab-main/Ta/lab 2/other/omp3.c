#include<omp.h>
#include<math.h>
#include<time.h>
#include<sys/time.h>
#include<unistd.h>
#include<sys/resource.h>
#include<stdio.h>
#include<stdlib.h>

#define NUM 500000
int main()
{
    int matrix[NUM];
    int a[NUM];
    int b[NUM];

    for(int i=0;i<NUM;i++)
    {
        a[i]=rand()%10000;
        b[i]=rand()%10000;
    }

    clock_t start= clock();

    for(int i=0;i<NUM;i++)
    {

        matrix[i]=a[i]+b[i];
        
    }
    clock_t end=clock();
    double time=(double)(end-start)/CLOCKS_PER_SEC;
    printf("Serial time taken is %f\n",time);


    omp_set_num_threads(4);
    double start1=omp_get_wtime();
    #pragma omp parallel for
    for(int i=0;i<NUM;i++)
    {
        matrix[i]=a[i]+b[i];
    }
    double end1=omp_get_wtime();
    //double time1=(double)(end1-start1)/CLOCKS_PER_SEC;
    printf("Parallel time taken is %f\n",end1-start1);


    return 0;
}