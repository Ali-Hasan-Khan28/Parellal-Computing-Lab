#include<omp.h>
#include<stdio.h>
#include<stdlib.h>

int add(int num,int x)
{
    return num+x;
}
int subtract(int num,int x)
{
    return num-x;
}
int multiply(int num,int x)
{
    return num*x;
}
int divide(int num,int x)
{
    if(x==0)
    {
        return -1;
    }
    else
    {
        return num/x;
    }
}



int main()
{
    omp_set_num_threads(8);
    int x=10;
    int i;
   #pragma omp parallel sections shared(x) private(i)
   {
    
    printf("Hamza\n");
    #pragma omp section
    {
        i=5;
        printf("The thread is %d. %d + %d = %d \n",omp_get_thread_num(),x,i,add(x,i));
    }
    #pragma omp section
    {    i=5;
        printf("The thread is %d. %d - %d = %d \n",omp_get_thread_num(),x,i,subtract(x,i));
    }
    #pragma omp section
    {    i=5;
        printf("The thread is %d. %d * %d = %d \n",omp_get_thread_num(),x,i,multiply(x,i));
    }
    #pragma omp section
    {    i=5;
        printf("The thread is %d. %d / %d = %d \n",omp_get_thread_num(),x,i,divide(x,i));        
    }
   } 

   return 0;











    return 0;
}