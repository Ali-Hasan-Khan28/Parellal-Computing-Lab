#include<pthread.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>
#include<stdio.h>
#include <bits/pthreadtypes.h>


#define num_threads 4

pthread_barrier_t barrier;

void *increment(void* arg)
{
    int thread_num=*(int*)arg;


    
    printf("Thread executing before barrier is %d\n",thread_num);
    
    pthread_barrier_wait(&barrier);

    printf("Thread executing after barrier is %d\n",thread_num);

}




int main()
{
    pthread_t threads[num_threads];
    int thread_ids[num_threads];
    pthread_barrier_init(&barrier,NULL,num_threads);
    for(int i=0;i<num_threads;i++)
    {
        thread_ids[i]=i;
        pthread_create(&threads[i],NULL,increment,&thread_ids[i]);
    }

    for(int i=0;i<num_threads;i++)
    {
        pthread_join(threads[i],NULL);
    }
    


    return 0;
}