#include <stdio.h>
#include <omp.h>
#include <stdbool.h>

#define MAX_NUM 1000
#define LOWER_LIMIT 1

bool is_prime(int num)
{
    if (num <= 1)
        return false;
    for (int i = 2; i * i <= num; i++)
    {
        if (num % i == 0)
            return false;
    }
    return true;
}

int main()
{
    int prime_count = 0;

#pragma omp parallel
    {
#pragma omp sections
        {
#pragma omp section
            {
                int local_count = 0;
                for (int i = LOWER_LIMIT; i <= MAX_NUM / 2; i++)
                {
                    if (is_prime(i))
                    {
                        local_count++;
                    }
                }
#pragma omp critical
                {
                    printf("Thread %d processed range [1, 500]: found %d primes\n",
                           omp_get_thread_num(), local_count);
                    prime_count += local_count;
                }
            }

#pragma omp section
            {
                int local_count = 0;
                for (int i = MAX_NUM / 2 + 1; i <= MAX_NUM; i++)
                {
                    if (is_prime(i))
                    {
                        local_count++;
                    }
                }
#pragma omp critical
                {
                    printf("Thread %d processed range [501, 1000]: found %d primes\n",
                           omp_get_thread_num(), local_count);
                    prime_count += local_count;
                }
            }
        }

#pragma omp barrier

#pragma omp single
        {
            printf("Total number of prime numbers in the range [1, %d]: %d\n", MAX_NUM, prime_count);
        }
    }

    return 0;
}
