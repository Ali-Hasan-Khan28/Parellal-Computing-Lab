#include<omp.h>
#include<math.h>
#include<time.h>
#include<sys/time.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/resource.h>

#define NUM 100000000
int main()
{
    int sum=0;
    clock_t start=clock();
    for(int i=1;i<NUM;i++)
    {
        sum+=i;

    }
    clock_t end=clock();
    double time= (double)(end-start)/CLOCKS_PER_SEC;
    printf("The sum if %d and the total time taken is %f",sum,time);
    sum=0;
    omp_set_num_threads(6);
    int result[6];
    start=omp_get_wtime();
    
    # pragma omp parallel
    {
            int id=omp_get_thread_num();
            result[id]=0;
            #pragma omp for
            for(int i=1;i<NUM;i++)
            {
               //#pragma omp atomic 
               result[id]+=i;

            }
        
    }
    for(int i=0;i<6;i++)
    {
        sum+=result[i];
    }
    time=omp_get_wtime()-start;
    printf("The sum if %d and the total time taken is %f",sum,time);

    sum=0;
    omp_set_num_threads(6);
    start=omp_get_wtime();
    
    # pragma omp parallel
    {
            
            #pragma omp for reduction(+:sum)
            for(int i=1;i<NUM;i++)
            {
               //#pragma omp atomic 
               sum+=i;

            }
        
    }
    time=omp_get_wtime()-start;
    printf("\nThe sum if %d and the total time taken is %f\n",sum,time);

    return 0;
}