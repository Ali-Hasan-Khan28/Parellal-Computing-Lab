#include<omp.h>
#include<math.h>
#include<time.h>
#include<sys/time.h>
#include<unistd.h>
#include<sys/resource.h>
#include<stdio.h>
#include<stdlib.h>

#define NUM 1000

int main()
{
    int matrix[NUM][NUM];
    int a[NUM][NUM];
    for(int i=0;i<NUM;i++)
        {
            
            for(int j=0;j<NUM;j++)
            {
                a[i][j]=rand()%10000;
            }
        }
    

    clock_t start= clock();

    for(int i=0;i<NUM;i++)
    {
        for(int j=0;j<NUM;j++)
        {
            matrix[i][j]=a[i][j];
        }
    }
    clock_t end=clock();
    double time=(double)(end-start)/CLOCKS_PER_SEC;
    printf("Serial time taken is %f\n",time);


    omp_set_num_threads(8);
    double start1=omp_get_wtime();
    #pragma omp parallel
    {
        #pragma omp for
        for(int i=0;i<NUM;i++)
        {
            
            for(int j=0;j<NUM;j++)
            {
                matrix[i][j]=a[i][j];
            }
        }
    }
    double end1=omp_get_wtime();
    //time=(double)(end-start)/CLOCKS_PER_SEC;
    printf("Parallel time taken is %f\n",end1-start1);


    return 0;
}