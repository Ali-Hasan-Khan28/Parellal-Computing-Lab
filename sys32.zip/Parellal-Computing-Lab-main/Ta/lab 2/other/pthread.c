#include<pthread.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>
#include<stdio.h>

#define size 1000
#define num_threads 4
int sum=0;

int result[num_threads]={0};
pthread_mutex_t mutex;


void *increment(void* arg)
{
    int thread_num=*(int*)arg;
    
    int start= thread_num*size/num_threads;
    int end= (thread_num+1)*size/num_threads;
    if(thread_num==3)
    {
        end=size;
    }
    for(int i=start;i<end;i++)
    {
        result[thread_num]+=i;
    }
    printf("Thread is %d. The result is %d\n",thread_num,result[thread_num]);
}

void *increment1(void* arg)
{
    int thread_num=*(int*)arg;
    
    int start= thread_num*size/num_threads;
    int end= (thread_num+1)*size/num_threads;
    for(int i=start;i<end;i++)
    {
        pthread_mutex_lock(&mutex);
        sum+=i;
        pthread_mutex_unlock(&mutex);
    }
    printf("Thread is %d. The result is %d\n",thread_num,result[thread_num]);
}


int main()
{
    pthread_t threads[num_threads];
    int thread_ids[num_threads];
    for(int i=0;i<num_threads;i++)
    {
        thread_ids[i]=i;
        pthread_create(&threads[i],NULL,increment,&thread_ids[i]);
    }

    for(int i=0;i<num_threads;i++)
    {
        pthread_join(threads[i],NULL);
    }
    for(int i=0;i<num_threads;i++)
    {
        sum+=result[i];
    }
    printf("Serial sum %d\n",sum);
    sum=0;
    for(int i=0;i<size;i++)
    {
        sum+=i;
    }
    printf("Parallel sum%d\n",sum);

    sum=0;
    for(int i=0;i<num_threads;i++)
    {
        thread_ids[i]=i;
        pthread_create(&threads[i],NULL,increment1,&thread_ids[i]);
    }

    for(int i=0;i<num_threads;i++)
    {
        pthread_join(threads[i],NULL);
    }
    printf("Parallel sum with mutex %d\n",sum);
    



    return 0;
}