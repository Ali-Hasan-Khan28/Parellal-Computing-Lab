#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define SIZE 4 // Define the size of the matrices

void printMatrix(int matrix[SIZE][SIZE])
{
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    int A[SIZE][SIZE], B[SIZE][SIZE], C[SIZE][SIZE];

    // Initialize matrices A and B with random values
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            A[i][j] = rand() % 10; // Random values from 0 to 9
            B[i][j] = rand() % 10; // Random values from 0 to 9
            C[i][j] = 0;           // Initialize result matrix C to zero
        }
    }

    printf("Matrix A:\n");
    printMatrix(A);

    printf("Matrix B:\n");
    printMatrix(B);

// Perform matrix multiplication in parallel
#pragma omp parallel for
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            for (int k = 0; k < SIZE; k++)
            {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }

    printf("Resulting Matrix C (A * B):\n");
    printMatrix(C);

    return 0;
}
