#include <stdio.h>
#include <omp.h>
#include <unistd.h> // For sleep()

int isPrime(int n){
    if(n < 2) {
        return 0;
    }
    
    for(int i = 2; i < n; i++) {
        if(n % i == 0) {
            return 0;
        }
    }
    return 1;
}

int main() {
    int lower_start = 0, lower_end = 500;
    int upper_start = 501, upper_end = 1000;
    int primeCount=0;

    #pragma omp parallel
    {
        #pragma omp sections
        {
            #pragma omp section
            {
                int local_prime=0;
                for(int i = lower_start; i <= lower_end; i++) {
                    if(isPrime(i)){
                    local_prime++;
                    // printf("Section 1: %d is prime thread: %d\n",i ,omp_get_thread_num());
                    }

                }

                #pragma omp atomic
                    primeCount += local_prime;
                
            }

            #pragma omp section
            {
                int local_prime=0;
                
                for(int i = upper_start; i < upper_end; i++) {
                       if(isPrime(i)){
                    local_prime++;

                    // printf("Section 2: %d is prime thread: %d\n",i ,omp_get_thread_num());
                    }
                }

                #pragma omp atomic
                    primeCount += local_prime;
            }

            

  
        }

        #pragma omp barrier

        #pragma omp single
        {
        printf("Total prime count : %d\n",primeCount);

        }

                //   printf("\nsection ended\n");
    }

    return 0;
}
