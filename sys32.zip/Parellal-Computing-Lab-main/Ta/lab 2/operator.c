#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    if (argc < 3)
    {
        printf("Usage: %s <operator> <array_size> <array_elements>\n", argv[0]);
        return 1;
    }

    // Get operator from the command-line argument
    char operator= argv[1][0];
    int array_size = atoi(argv[2]);

    // Dynamically allocate memory for the array
    int *array = (int *)malloc(array_size * sizeof(int));
    if (array == NULL)
    {
        printf("Memory allocation failed\n");
        return 1;
    }

    // Read array elements from command-line arguments
    for (int i = 0; i < array_size; i++)
    {
        array[i] = atoi(argv[i + 3]);
    }

    // Perform the specified operation
    int result = array[0]; // Initialize result to the first element
    for (int i = 1; i < array_size; i++)
    {
        switch (operator)
        {
        case '+':
            result += array[i];
            break;
        case '-':
            result -= array[i];
            break;
        case '*':
            result *= array[i];
            break;
        case '/':
            if (array[i] != 0)
            {
                result /= array[i];
            }
            else
            {
                printf("Division by zero is not allowed.\n");
                free(array);
                return 1;
            }
            break;
        default:
            printf("Unknown operator.\n");
            free(array);
            return 1;
        }
    }

    // Print the result
    printf("Result: %d\n", result);

    // Free dynamically allocated memory
    free(array);

    return 0;
}
