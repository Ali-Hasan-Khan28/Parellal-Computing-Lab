#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

#define BUFFER_SIZE 5 // Bounded buffer size
int buffer[BUFFER_SIZE];
int count = 0;       // Number of items in the buffer
int in = 0, out = 0; // Indexes for producer and consumer

pthread_mutex_t lock;
pthread_cond_t not_empty, not_full; // Condition variables

// Producer function
void *producer(void *arg)
{
    while (1)
    {
        int item = rand() % 100; // Produce an item

        // Lock before modifying the buffer
        pthread_mutex_lock(&lock);

        // Wait if the buffer is full
        while (count == BUFFER_SIZE)
        {
            pthread_cond_wait(&not_full, &lock);
        }

        // Add item to the buffer
        buffer[in] = item;
        in = (in + 1) % BUFFER_SIZE;
        count++;
        printf("Produced: %d\n", item);

        // Signal that the buffer is not empty
        pthread_cond_signal(&not_empty);

        // Unlock
        pthread_mutex_unlock(&lock);

        sleep(1); // Simulate time taken to produce an item
    }
}

// Consumer function
void *consumer(void *arg)
{
    while (1)
    {
        // Lock before modifying the buffer
        pthread_mutex_lock(&lock);

        // Wait if the buffer is empty
        while (count == 0)
        {
            pthread_cond_wait(&not_empty, &lock);
        }

        // Remove item from the buffer
        int item = buffer[out];
        out = (out + 1) % BUFFER_SIZE;
        count--;
        printf("Consumed: %d\n", item);

        // Signal that the buffer is not full
        pthread_cond_signal(&not_full);

        // Unlock
        pthread_mutex_unlock(&lock);

        sleep(2); // Simulate time taken to consume an item
    }
}

int main()
{
    pthread_t prod_thread, cons_thread;

    // Initialize mutex and condition variables
    pthread_mutex_init(&lock, NULL);
    pthread_cond_init(&not_empty, NULL);
    pthread_cond_init(&not_full, NULL);

    // Create producer and consumer threads
    pthread_create(&prod_thread, NULL, producer, NULL);
    pthread_create(&cons_thread, NULL, consumer, NULL);

    // Join threads (they run indefinitely in this example)
    pthread_join(prod_thread, NULL);
    pthread_join(cons_thread, NULL);

    // Destroy mutex and condition variables
    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&not_empty);
    pthread_cond_destroy(&not_full);

    return 0;
}
