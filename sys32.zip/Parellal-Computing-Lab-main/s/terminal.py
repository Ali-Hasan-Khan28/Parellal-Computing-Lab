import openai
import os

# Set up your OpenAI API key directly
openai.api_key = "sk-ymxjFPLELK_fGYpTXHlwSFJisumP4A-NnZrUMIL6IZT3BlbkFJ2wGd8mS-9sv4W_ZY_7duVS9uOQbp-0sNHXvtV5rM0A"  # Replace with your actual API key

# Function to interact with GPT models
def chat_with_gpt(prompt):
    try:
        # Sending request to OpenAI
        response = openai.completions.create(
            model="gpt-3.5-turbo-instruct",  # Use the correct model name
            prompt=prompt,
            max_tokens=2048,
            temperature=0.3,
        )
        # Access the 'text' field in the response
        response_text = response.choices[0].text.strip()
        return response_text
    except Exception as e:
        return f"Error: {e}"

if __name__ == "__main__":
    print("ChatGPT Terminal: Type 'exit' to quit.")
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            break
        response = chat_with_gpt(user_input)
        print(f"Response: {response}")
